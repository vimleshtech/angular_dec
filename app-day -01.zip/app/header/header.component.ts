import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  name
  constructor() { 

  this.name  = ''
  }


  ngOnInit() {
  }

  getName(event){

    this.name = event.target.value;
    

  }
}
